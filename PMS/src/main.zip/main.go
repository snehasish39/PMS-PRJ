package main

import (
	"PMS/handlers"
	"context"
	"encoding/json"
	"fmt"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	ginadapter "github.com/awslabs/aws-lambda-go-api-proxy/gin"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

var ginLambda *ginadapter.GinLambda
var router *gin.Engine

func main() {
	const functionName = "main.main"
	fmt.Println(functionName)

	router = gin.Default()
	cors.Default()

	handlers.SetupRoutes(router)
	lambda.Start(LambdaHandler)

}

func LambdaHandler(ctx context.Context, input map[string]interface{}) (interface{}, error) {

	inputBytes, _ := json.Marshal(input)

	var awsAPIGatewayEvent events.APIGatewayProxyRequest
	err := json.Unmarshal(inputBytes, &awsAPIGatewayEvent)
	if err == nil && awsAPIGatewayEvent.HTTPMethod != "" {
		awsEvent := awsAPIGatewayEvent
		return ginLambda.ProxyWithContext(ctx, awsEvent)
	}

	return "invalid request type", nil
}
